const jwt = require('jsonwebtoken');
const SECRET = 'taskflow_secret_key_2024';

module.exports = (req, res, next) => {
  const header = req.headers['authorization'];
  const token = header && header.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token. Please login.' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    return res.status(401).json({ message: 'Invalid token. Please login again.' });
  }
};
