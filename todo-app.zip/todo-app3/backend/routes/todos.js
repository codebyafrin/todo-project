const express = require('express');
const { readTodos, writeTodos, generateId } = require('../db/database');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

// GET all todos
router.get('/', (req, res) => {
  try {
    const all = readTodos();
    let todos = all.filter(t => t.userId === req.user.id);

    const { completed, priority, search } = req.query;
    if (completed === 'true') todos = todos.filter(t => t.completed === true);
    if (completed === 'false') todos = todos.filter(t => t.completed === false);
    if (priority) todos = todos.filter(t => t.priority === priority);
    if (search) {
      const s = search.toLowerCase();
      todos = todos.filter(t => t.title.toLowerCase().includes(s) || (t.description || '').toLowerCase().includes(s));
    }

    todos.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ todos });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch todos.' });
  }
});

// GET stats
router.get('/stats', (req, res) => {
  try {
    const todos = readTodos().filter(t => t.userId === req.user.id);
    const total = todos.length;
    const completed = todos.filter(t => t.completed).length;
    const pending = total - completed;
    const highPriority = todos.filter(t => t.priority === 'high' && !t.completed).length;
    res.json({ stats: { total, completed, pending, highPriority } });
  } catch (err) {
    res.status(500).json({ message: 'Failed.' });
  }
});

// POST create todo
router.post('/', (req, res) => {
  try {
    const { title, description, priority, due_date, category } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ message: 'Title is required.' });

    const todos = readTodos();
    const newTodo = {
      id: generateId(),
      userId: req.user.id,
      title: title.trim(),
      description: description || '',
      completed: false,
      priority: priority || 'medium',
      due_date: due_date || '',
      category: category || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    todos.push(newTodo);
    writeTodos(todos);
    res.status(201).json({ message: 'Todo created!', todo: newTodo });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create todo.' });
  }
});

// PUT update todo
router.put('/:id', (req, res) => {
  try {
    const todos = readTodos();
    const idx = todos.findIndex(t => t.id === req.params.id && t.userId === req.user.id);
    if (idx === -1) return res.status(404).json({ message: 'Todo not found.' });

    const t = todos[idx];
    todos[idx] = {
      ...t,
      title: req.body.title !== undefined ? req.body.title : t.title,
      description: req.body.description !== undefined ? req.body.description : t.description,
      completed: req.body.completed !== undefined ? req.body.completed : t.completed,
      priority: req.body.priority !== undefined ? req.body.priority : t.priority,
      due_date: req.body.due_date !== undefined ? req.body.due_date : t.due_date,
      category: req.body.category !== undefined ? req.body.category : t.category,
      updatedAt: new Date().toISOString()
    };
    writeTodos(todos);
    res.json({ message: 'Updated!', todo: todos[idx] });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update.' });
  }
});

// DELETE todo
router.delete('/:id', (req, res) => {
  try {
    let todos = readTodos();
    const exists = todos.find(t => t.id === req.params.id && t.userId === req.user.id);
    if (!exists) return res.status(404).json({ message: 'Todo not found.' });
    todos = todos.filter(t => !(t.id === req.params.id && t.userId === req.user.id));
    writeTodos(todos);
    res.json({ message: 'Deleted!' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete.' });
  }
});

// PATCH toggle
router.patch('/:id/toggle', (req, res) => {
  try {
    const todos = readTodos();
    const idx = todos.findIndex(t => t.id === req.params.id && t.userId === req.user.id);
    if (idx === -1) return res.status(404).json({ message: 'Todo not found.' });
    todos[idx].completed = !todos[idx].completed;
    todos[idx].updatedAt = new Date().toISOString();
    writeTodos(todos);
    res.json({ message: 'Toggled!', todo: todos[idx] });
  } catch (err) {
    res.status(500).json({ message: 'Failed to toggle.' });
  }
});

module.exports = router;
