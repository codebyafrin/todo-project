const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { readUsers, writeUsers, generateId } = require('../db/database');

const router = express.Router();
const SECRET = 'taskflow_secret_key_2024';

// REGISTER
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ message: 'Name is required.' });
    if (!email || !email.trim()) return res.status(400).json({ message: 'Email is required.' });
    if (!password) return res.status(400).json({ message: 'Password is required.' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters.' });

    const users = readUsers();
    const emailLower = email.toLowerCase().trim();

    const exists = users.find(u => u.email === emailLower);
    if (exists) return res.status(409).json({ message: 'This email is already registered. Please login instead.' });

    const hashed = await bcrypt.hash(password, 10);
    const newUser = {
      id: generateId(),
      name: name.trim(),
      email: emailLower,
      password: hashed,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    writeUsers(users);

    const token = jwt.sign({ id: newUser.id, name: newUser.name, email: newUser.email }, SECRET, { expiresIn: '7d' });

    console.log('✅ New user registered:', emailLower);

    res.status(201).json({
      message: 'Account created!',
      token,
      user: { id: newUser.id, name: newUser.name, email: newUser.email }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error: ' + err.message });
  }
});

// LOGIN
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) return res.status(400).json({ message: 'Email and password required.' });

    const users = readUsers();
    const emailLower = email.toLowerCase().trim();

    console.log('Login attempt:', emailLower);
    console.log('Total users in DB:', users.length);
    console.log('Users:', users.map(u => u.email));

    const user = users.find(u => u.email === emailLower);
    if (!user) {
      console.log('User not found:', emailLower);
      return res.status(401).json({ message: 'No account found with this email. Please register first.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log('Wrong password for:', emailLower);
      return res.status(401).json({ message: 'Wrong password. Please try again.' });
    }

    const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, SECRET, { expiresIn: '7d' });

    console.log('✅ Login success:', emailLower);

    res.json({
      message: 'Login successful!',
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error: ' + err.message });
  }
});

// GET ME
const authMiddleware = require('../middleware/auth');
router.get('/me', authMiddleware, (req, res) => {
  const users = readUsers();
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ message: 'User not found.' });
  res.json({ user: { id: user.id, name: user.name, email: user.email } });
});

module.exports = router;
