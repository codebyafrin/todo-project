const express = require('express');
const path = require('path');

const app = express();
const PORT = 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/todos', require('./routes/todos'));

app.get('/api/health', (req, res) => res.json({ status: 'OK' }));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
  console.log('\n✅ Database ready (JSON files)');
  console.log(`🚀 Server running → http://localhost:${PORT}`);
  console.log(`🌐 Open in browser: http://localhost:${PORT}\n`);
});
