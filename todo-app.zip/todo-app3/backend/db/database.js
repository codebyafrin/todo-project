const fs = require('fs');
const path = require('path');

const USERS_FILE = path.join(__dirname, 'users.json');
const TODOS_FILE = path.join(__dirname, 'todos.json');

// Create files if they don't exist
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '[]');
if (!fs.existsSync(TODOS_FILE)) fs.writeFileSync(TODOS_FILE, '[]');

function readUsers() {
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

function readTodos() {
  try {
    return JSON.parse(fs.readFileSync(TODOS_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeTodos(todos) {
  fs.writeFileSync(TODOS_FILE, JSON.stringify(todos, null, 2));
}

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

console.log('✅ Database ready (JSON files)');

module.exports = { readUsers, writeUsers, readTodos, writeTodos, generateId };
